# **App Name**: Askep Pintar 3S

## Core Features:

- Mesin Diagnosis Klinis: Antarmuka pencarian lanjutan untuk menelusuri diagnosis medis berdasarkan standar pengkodean ICD-10.
- Navigator Hierarki 3S: Sistem pemetaan visual yang menghubungkan Diagnosis Medis (ICD-10) secara langsung ke SDKI (Diagnosis), SLKI (Luaran), dan SIKI (Intervensi).
- Asisten Perawatan Cerdas: Sebuah tool bertenaga AI yang mengevaluasi deskripsi status pasien untuk merekomendasikan rencana asuhan keperawatan yang spesifik dan diprioritaskan menggunakan logika 3S.
- Daftar Periksa Protokol OTEK: Modul interaktif yang mengategorikan intervensi keperawatan ke dalam fase Observasi, Terapeutik, Edukasi, dan Kolaborasi untuk alur kerja yang lebih baik.
- Utilitas Ekspor Standar: Menghasilkan laporan PDF siap cetak yang bersih dari rencana asuhan keperawatan lengkap yang sesuai untuk rekam medis.

## Style Guidelines:

- Warna Utama: Clinical Teal (#247B82), membangkitkan presisi dan lingkungan layanan kesehatan profesional.
- Warna Latar Belakang: Putih Bedah Bersih (#F2F7F7), varian desaturasi dari rona utama untuk ruang kerja dengan kejelasan tinggi.
- Warna Aksen: Hijau Vitalitas (#3AA36B), rona analog yang digunakan untuk tombol aksi dan indikator status.
- Font Judul: 'Inter' (sans-serif) untuk tampilan modern, objektif, dan mekanis yang memastikan keterbacaan maksimum dalam pengaturan klinis.
- Font Isi: 'PT Sans' (sans-serif) untuk memberikan sentuhan kehangatan humanis dan kepribadian pada teks yang berfokus pada pasien.
- Tata letak berbasis kartu yang responsif, terinspirasi oleh dasbor analitik, memastikan kemudahan penggunaan pada tablet seluler selama kunjungan bangsal.
- Pintu masuk bertahap yang lembut untuk item daftar dan ekspansi vertikal yang mulus untuk detail intervensi bertingkat.