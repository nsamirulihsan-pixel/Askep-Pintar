'use server';
/**
 * @fileOverview Sebuah tool bertenaga AI yang mengevaluasi deskripsi status pasien
 * untuk merekomendasikan rencana asuhan keperawatan (3S) dan dokumentasi SOAP/CPPT
 * berdasarkan standar PPNI terbaru.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiAssistedCarePlanGenerationInputSchema = z.object({
  patientDescription: z
    .string()
    .describe(
      'Deskripsi naratif mengenai status klinis pasien, termasuk keluhan utama, riwayat medis, dan observasi lainnya.'
    ),
});
export type AiAssistedCarePlanGenerationInput = z.infer<
  typeof AiAssistedCarePlanGenerationInputSchema
>;

const CarePlanItemSchema = z.object({
  priority: z
    .number()
    .describe('Prioritas item keperawatan, angka lebih rendah berarti lebih tinggi prioritasnya.'),
  description: z.string().describe('Deskripsi item keperawatan.'),
});

const SikiItemSchema = z.object({
  priority: z.number(),
  title: z.string().describe('Judul Intervensi Utama (misal: Manajemen Jalan Napas)'),
  details: z.object({
    observasi: z.array(z.string()).describe('Daftar tindakan observasi'),
    terapeutik: z.array(z.string()).describe('Daftar tindakan terapeutik'),
    edukasi: z.array(z.string()).describe('Daftar tindakan edukasi'),
    kolaborasi: z.array(z.string()).describe('Daftar tindakan kolaborasi'),
  }).describe('Rincian tindakan OTEK'),
});

const SoapSchema = z.object({
  s: z.string().describe('Subjective: Keluhan pasien yang relevan dengan SDKI.'),
  o: z.string().describe('Objective: Data klinis, TTV, dan temuan fisik terukur.'),
  a: z.string().describe('Assessment: Label Diagnosis SDKI yang ditegakkan.'),
  p: z.string().describe('Plan: Rencana intervensi spesifik merujuk pada label SIKI.'),
});

const AiAssistedCarePlanGenerationOutputSchema = z.object({
  sdki: z
    .array(CarePlanItemSchema)
    .describe(
      'Daftar diagnosis keperawatan (SDKI) yang direkomendasikan, diurutkan berdasarkan prioritas.'
    ),
  slki: z
    .array(CarePlanItemSchema)
    .describe(
      'Daftar luaran keperawatan (SLKI) yang diharapkan.'
    ),
  siki: z
    .array(SikiItemSchema)
    .describe(
      'Daftar intervensi keperawatan (SIKI) rinci (OTEK).'
    ),
  soap: SoapSchema.describe('Dokumentasi SOAP profesional untuk CPPT.'),
  ppaInstructions: z.array(z.string()).describe('Daftar instruksi PPA atau implementasi keperawatan spesifik untuk kolom instruksi CPPT.'),
});
export type AiAssistedCarePlanGenerationOutput = z.infer<
  typeof AiAssistedCarePlanGenerationOutputSchema
>;

export async function aiAssistedCarePlanGeneration(
  input: AiAssistedCarePlanGenerationInput
): Promise<AiAssistedCarePlanGenerationOutput> {
  return aiAssistedCarePlanGenerationFlow(input);
}

const generateCarePlanPrompt = ai.definePrompt({
  name: 'generateCarePlanPrompt',
  input: {schema: AiAssistedCarePlanGenerationInputSchema},
  output: {schema: AiAssistedCarePlanGenerationOutputSchema},
  prompt: `Anda adalah pakar Informatika Keperawatan yang ahli dalam standar PPNI (SDKI, SLKI, SIKI) dan dokumentasi hukum kesehatan.

TUGAS ANDA:
Analisis deskripsi status pasien berikut dan susun rencana asuhan keperawatan yang presisi termasuk dokumentasi CPPT lengkap.

INSTRUKSI KHUSUS SOAP (CPPT):
Gunakan model dokumentasi terbaru yang mengintegrasikan 3S:
- S (Subjective): Catat keluhan pasien secara naratif namun fokus pada indikator gejala mayor/minor SDKI.
- O (Objective): Catat temuan klinis yang dapat divalidasi (TTV, hasil lab, pemeriksaan fisik) yang relevan untuk evaluasi SLKI nanti.
- A (Assessment): Tuliskan Label Diagnosis SDKI secara lengkap (misal: "D.0001 Bersihan Jalan Napas Tidak Efektif").
- P (Plan): Tuliskan rencana tindakan dengan menyebutkan Label SIKI utama yang akan diimplementasikan.

INSTRUKSI IMPLEMENTASI (KOLOM INSTRUKSI PPA):
Berikan daftar instruksi tindakan nyata atau implementasi keperawatan yang harus dilakukan oleh perawat jaga (ppaInstructions). Ini akan dimasukkan ke dalam kolom "Instruksi PPA" di tabel CPPT.

INSTRUKSI 3S:
1. SDKI: Identifikasi diagnosis berdasarkan data pendukung yang ada.
2. SLKI: Tentukan kriteria hasil yang realistis dan terukur.
3. SIKI: Berikan intervensi rinci dengan format OTEK (Observasi, Terapeutik, Edukasi, Kolaborasi).

Deskripsi Status Pasien:
{{{patientDescription}}}

Pastikan terminologi yang digunakan profesional, paham terhadap typo perawat, dan sesuai dengan standar keperawatan Indonesia.`,
});

const aiAssistedCarePlanGenerationFlow = ai.defineFlow(
  {
    name: 'aiAssistedCarePlanGenerationFlow',
    inputSchema: AiAssistedCarePlanGenerationInputSchema,
    outputSchema: AiAssistedCarePlanGenerationOutputSchema,
  },
  async (input) => {
    const {output} = await generateCarePlanPrompt(input);
    return output!;
  }
);