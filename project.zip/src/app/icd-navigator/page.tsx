
"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, ChevronRight, Activity, Target, Shield, Sparkles, ArrowRight, Stethoscope } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// Database ICD-10 yang diperluas dengan fokus pada kasus umum di Indonesia
const ICD_DATA = [
  {
    code: "A00",
    name: "Kolera",
    sdki: ["D.0020 Diare", "D.0023 Hipovolemia"],
    slki: ["L.04033 Eliminasi Fekal Membaik", "L.03020 Status Cairan Membaik"],
    siki: ["I.03101 Manajemen Diare", "I.03116 Manajemen Hipovolemia"]
  },
  {
    code: "A01",
    name: "Demam Tifoid (Typhoid Fever)",
    sdki: ["D.0130 Hipertermia", "D.0019 Defisit Nutrisi"],
    slki: ["L.14134 Termoregulasi Membaik", "L.03030 Status Nutrisi Membaik"],
    siki: ["I.15506 Manajemen Hipertermia", "I.03119 Manajemen Nutrisi"]
  },
  {
    code: "A15",
    name: "Tuberkulosis Paru (TBC)",
    sdki: ["D.0001 Bersihkan Jalan Napas Tidak Efektif", "D.0019 Defisit Nutrisi"],
    slki: ["L.01001 Bersihan Jalan Napas Meningkat", "L.03030 Status Nutrisi Membaik"],
    siki: ["I.01006 Latihan Batuk Efektif", "I.03119 Manajemen Nutrisi"]
  },
  {
    code: "A90",
    name: "Demam Dengue (DHF/DBD)",
    sdki: ["D.0130 Hipertermia", "D.0023 Hipovolemia", "D.0012 Risiko Perdarahan"],
    slki: ["L.14134 Termoregulasi Membaik", "L.03020 Status Cairan Membaik"],
    siki: ["I.15506 Manajemen Hipertermia", "I.03116 Manajemen Hipovolemia", "I.02067 Pencegahan Perdarahan"]
  },
  {
    code: "E11",
    name: "Diabetes melitus tipe 2",
    sdki: ["D.0027 Ketidakstabilan Kadar Glukosa Darah", "D.0129 Gangguan Integritas Kulit"],
    slki: ["L.03022 Kestabilan Kadar Glukosa Darah Meningkat", "L.14125 Integritas Kulit Meningkat"],
    siki: ["I.03115 Manajemen Hiperglikemia", "I.14564 Perawatan Luka"]
  },
  {
    code: "I10",
    name: "Hipertensi esensial (primer)",
    sdki: ["D.0008 Penurunan Curah Jantung", "D.0077 Nyeri Akut (Sakit Kepala)"],
    slki: ["L.02008 Curah Jantung Meningkat", "L.08066 Tingkat Nyeri Menurun"],
    siki: ["I.02075 Perawatan Jantung", "I.08238 Manajemen Nyeri"]
  },
  {
    code: "I21",
    name: "Infark miokard akut (STEMI/NSTEMI)",
    sdki: ["D.0008 Penurunan Curah Jantung", "D.0077 Nyeri Akut"],
    slki: ["L.02008 Curah Jantung Meningkat", "L.08066 Tingkat Nyeri Menurun"],
    siki: ["I.02075 Perawatan Jantung", "I.08238 Manajemen Nyeri"]
  },
  {
    code: "J45",
    name: "Asma Bronkial",
    sdki: ["D.0001 Bersihkan Jalan Napas Tidak Efektif", "D.0005 Pola Napas Tidak Efektif"],
    slki: ["L.01001 Bersihan Jalan Napas Meningkat", "L.01004 Pola Napas Membaik"],
    siki: ["I.01006 Latihan Batuk Efektif", "I.01011 Manajemen Jalan Napas"]
  },
  {
    code: "K29",
    name: "Gastritis / Dispepsia",
    sdki: ["D.0077 Nyeri Akut", "D.0019 Defisit Nutrisi (Mual/Muntah)"],
    slki: ["L.08066 Tingkat Nyeri Menurun", "L.03030 Status Nutrisi Membaik"],
    siki: ["I.08238 Manajemen Nyeri", "I.03119 Manajemen Nutrisi"]
  },
  {
    code: "N18",
    name: "Penyakit ginjal kronik (CKD)",
    sdki: ["D.0022 Hipervolemia", "D.0027 Ketidakstabilan Kadar Glukosa Darah"],
    slki: ["L.03020 Status Cairan Membaik", "L.05046 Fungsi Jaringan Renal Meningkat"],
    siki: ["I.03114 Manajemen Hipervolemia", "I.02041 Monitor Cairan"]
  },
  {
    code: "Z00",
    name: "Pemeriksaan umum (Medical Check Up)",
    sdki: ["D.0111 Defisit Pengetahuan", "D.0110 Kesiapan Peningkatan Manajemen Kesehatan"],
    slki: ["L.12111 Tingkat Pengetahuan Meningkat", "L.12104 Manajemen Kesehatan Meningkat"],
    siki: ["I.12383 Edukasi Kesehatan"]
  }
];

export default function IcdNavigator() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDiagnosis, setSelectedDiagnosis] = useState(ICD_DATA[3]); // Default DHF
  const router = useRouter();

  // Memofilter data secara efisien setiap kali searchTerm berubah
  const filteredData = useMemo(() => {
    if (!searchTerm.trim()) return ICD_DATA;
    const lowerSearch = searchTerm.toLowerCase();
    return ICD_DATA.filter(item => 
      item.name.toLowerCase().includes(lowerSearch) || 
      item.code.toLowerCase().includes(lowerSearch)
    );
  }, [searchTerm]);

  const handleProcessWithAI = () => {
    const prompt = `Pasien terdiagnosa medis dengan ${selectedDiagnosis.name} (${selectedDiagnosis.code}). Tolong buatkan rencana asuhan keperawatan yang komprehensif berdasarkan standar SDKI, SLKI, dan SIKI.`;
    router.push(`/assistant?prefill=${encodeURIComponent(prompt)}`);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="space-y-2">
        <h1 className="text-3xl font-headline font-bold text-primary flex items-center gap-2">
          <Stethoscope className="h-8 w-8 text-accent" />
          Navigator Hierarki 3S
        </h1>
        <p className="text-muted-foreground font-body">Hubungkan Diagnosis Medis ICD-10 dengan Standar Keperawatan (SDKI, SLKI, SIKI) secara instan.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Panel Pencarian (Kiri) */}
        <Card className="lg:col-span-4 h-fit border-none shadow-sm overflow-hidden bg-white/50 backdrop-blur-sm">
          <CardHeader className="bg-muted/30">
            <CardTitle className="text-lg flex items-center gap-2">
              <Search className="h-4 w-4" />
              Cari Diagnosis
            </CardTitle>
            <div className="relative pt-2">
              <Search className="absolute left-3 top-5 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input 
                placeholder="Ketik nama penyakit atau kode..." 
                className="pl-10 rounded-full bg-white border-primary/20 focus:ring-primary h-11"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y max-h-[500px] overflow-y-auto scrollbar-thin scrollbar-thumb-primary/20">
              {filteredData.map((item) => (
                <button
                  key={item.code}
                  onClick={() => setSelectedDiagnosis(item)}
                  className={cn(
                    "w-full text-left p-4 hover:bg-primary/5 transition-all flex justify-between items-center group relative",
                    selectedDiagnosis.code === item.code ? "bg-primary/10 border-l-4 border-primary" : ""
                  )}
                >
                  <div className="space-y-1">
                    <span className={cn(
                      "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase",
                      selectedDiagnosis.code === item.code ? "bg-primary text-white" : "bg-muted text-muted-foreground"
                    )}>
                      {item.code}
                    </span>
                    <p className="font-semibold text-sm group-hover:text-primary transition-colors">{item.name}</p>
                  </div>
                  <ChevronRight className={cn(
                    "h-4 w-4 transition-transform", 
                    selectedDiagnosis.code === item.code ? "rotate-90 text-primary" : "text-muted-foreground group-hover:translate-x-1"
                  )} />
                </button>
              ))}
              {filteredData.length === 0 && (
                <div className="p-12 text-center text-muted-foreground italic flex flex-col items-center gap-2">
                  <Activity className="h-8 w-8 opacity-20" />
                  <p>Tidak ada diagnosis ditemukan.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Panel Detail (Kanan) */}
        <div className="lg:col-span-8 space-y-6">
          <Card className="border-none shadow-sm bg-white overflow-hidden border-t-4 border-t-primary">
            <CardHeader className="bg-gradient-to-r from-primary to-primary/80 text-white p-8">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-2">
                  <Badge variant="secondary" className="bg-white/20 text-white hover:bg-white/30 border-none px-3 py-1">
                    ICD-10 KODE: {selectedDiagnosis.code}
                  </Badge>
                  <CardTitle className="text-3xl font-headline font-bold">{selectedDiagnosis.name}</CardTitle>
                </div>
                <Button 
                  onClick={handleProcessWithAI}
                  className="bg-accent hover:bg-accent/90 text-white rounded-full flex items-center gap-2 shadow-xl h-12 px-6 transform hover:scale-105 transition-transform"
                >
                  <Sparkles className="h-5 w-5" />
                  Buat Askep AI
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-8 space-y-10">
              {/* SDKI Section */}
              <div className="space-y-4 animate-in slide-in-from-bottom-2 duration-300">
                <div className="flex items-center gap-3 text-primary font-bold border-b pb-2">
                  <Shield className="h-6 w-6" />
                  <h3 className="text-lg uppercase tracking-tight">SDKI (Diagnosis Keperawatan)</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedDiagnosis.sdki.map((item, i) => (
                    <div key={i} className="p-4 rounded-xl border bg-blue-50/30 border-blue-100 text-sm font-medium flex items-center gap-3">
                      <div className="h-2 w-2 rounded-full bg-blue-500 shrink-0" />
                      {item}
                    </div>
                  ))}
                </div>
              </div>

              {/* SLKI Section */}
              <div className="space-y-4 animate-in slide-in-from-bottom-2 duration-500">
                <div className="flex items-center gap-3 text-accent font-bold border-b pb-2">
                  <Target className="h-6 w-6" />
                  <h3 className="text-lg uppercase tracking-tight">SLKI (Luaran Keperawatan)</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedDiagnosis.slki.map((item, i) => (
                    <div key={i} className="p-4 rounded-xl border bg-green-50/30 border-green-100 text-sm font-medium flex items-center gap-3">
                      <div className="h-2 w-2 rounded-full bg-green-500 shrink-0" />
                      {item}
                    </div>
                  ))}
                </div>
              </div>

              {/* SIKI Section */}
              <div className="space-y-4 animate-in slide-in-from-bottom-2 duration-700">
                <div className="flex items-center gap-3 text-amber-600 font-bold border-b pb-2">
                  <Activity className="h-6 w-6" />
                  <h3 className="text-lg uppercase tracking-tight">SIKI (Intervensi Utama)</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedDiagnosis.siki.map((item, i) => (
                    <div key={i} className="p-4 rounded-xl border bg-amber-50/30 border-amber-100 text-sm font-medium flex items-center gap-3">
                      <div className="h-2 w-2 rounded-full bg-amber-500 shrink-0" />
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
