
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, Sparkles, Activity, ShieldCheck, Map, ArrowRight, Smartphone, CheckCircle2 } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { cn } from "@/lib/utils";

const features = [
  {
    title: "Mesin Diagnosis Klinis",
    description: "Cari diagnosis medis berdasarkan standar ICD-10 secara akurat.",
    icon: Search,
    href: "/icd-navigator",
    color: "text-blue-600",
    bg: "bg-blue-100",
  },
  {
    title: "Asisten Perawatan Cerdas",
    description: "AI yang merekomendasikan rencana asuhan (SDKI, SLKI, SIKI) dalam detik.",
    icon: Sparkles,
    href: "/assistant",
    color: "text-amber-600",
    bg: "bg-amber-100",
  },
  {
    title: "Protokol OTEK",
    description: "Intervensi terstruktur: Observasi, Terapeutik, Edukasi, dan Kolaborasi.",
    icon: Activity,
    href: "/otek",
    color: "text-green-600",
    bg: "bg-green-100",
  },
  {
    title: "Navigator Hierarki 3S",
    description: "Hubungkan diagnosis medis dengan intervensi keperawatan standar.",
    icon: Map,
    href: "/icd-navigator",
    color: "text-indigo-600",
    bg: "bg-indigo-100",
  },
];

export default function Home() {
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-medical');

  return (
    <div className="space-y-12 pb-12">
      {/* Hero Section */}
      <section className="relative rounded-3xl overflow-hidden bg-primary text-white h-[450px] flex items-center">
        {heroImage && (
          <Image
            src={heroImage.imageUrl}
            alt={heroImage.description}
            fill
            className="object-cover opacity-20"
            data-ai-hint={heroImage.imageHint}
          />
        )}
        <div className="relative z-10 p-8 md:p-12 max-w-2xl space-y-6">
          <div className="inline-flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full text-xs font-bold tracking-widest uppercase mb-4">
            <Activity className="h-3 w-3" /> Standar PPNI Terbaru
          </div>
          <h1 className="text-4xl md:text-5xl font-headline font-bold leading-tight">
            Presisi dalam Setiap Intervensi Keperawatan
          </h1>
          <p className="text-lg text-primary-foreground/80 font-body">
            ASKEP PINTAR by Ns. AMIRUL membantu profesional kesehatan merancang asuhan yang standar, efisien, dan berbasis bukti nyata (3S).
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg" variant="secondary" asChild className="rounded-full shadow-lg">
              <Link href="/assistant">Mulai Askep AI</Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="rounded-full bg-white/10 hover:bg-white/20 border-white text-white">
              <Link href="/icd-navigator">Cari ICD-10</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((feature, idx) => {
          const Icon = feature.icon;
          return (
            <Card key={idx} className="hover:shadow-xl transition-all duration-300 animate-fade-in-up border-none shadow-sm group" style={{ animationDelay: `${idx * 100}ms` }}>
              <CardHeader>
                <div className={cn("p-3 w-fit rounded-xl mb-4 transition-colors", feature.bg)}>
                  <Icon className={cn("h-6 w-6", feature.color)} />
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
                <CardDescription className="font-body">{feature.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="link" asChild className="p-0 text-primary font-semibold group-hover:translate-x-1 transition-transform">
                  <Link href={feature.href} className="flex items-center gap-1">
                    Buka Fitur <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </section>

      {/* Stats/Status Section */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 border-none shadow-sm">
          <CardHeader>
            <CardTitle>Panduan Penggunaan 3S</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50 border border-transparent hover:border-primary/20 transition-colors">
              <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center font-bold shrink-0">1</div>
              <div>
                <p className="font-bold">SDKI (Diagnosis)</p>
                <p className="text-sm text-muted-foreground">Identifikasi masalah kesehatan pasien menggunakan kriteria objektif dan subjektif.</p>
              </div>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50 border border-transparent hover:border-primary/20 transition-colors">
              <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center font-bold shrink-0">2</div>
              <div>
                <p className="font-bold">SLKI (Luaran)</p>
                <p className="text-sm text-muted-foreground">Tentukan hasil yang diharapkan setelah dilakukan intervensi keperawatan.</p>
              </div>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50 border border-transparent hover:border-primary/20 transition-colors">
              <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center font-bold shrink-0">3</div>
              <div>
                <p className="font-bold">SIKI (Intervensi)</p>
                <p className="text-sm text-muted-foreground">Pilih tindakan keperawatan yang paling efektif untuk mencapai luaran.</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-accent text-white border-none shadow-lg overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <ShieldCheck className="h-24 w-24" />
          </div>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 relative z-10">
              <ShieldCheck className="h-6 w-6" />
              Sertifikasi Standar
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 relative z-10">
            <p className="text-sm opacity-90 font-body">
              Seluruh basis data ASKEP PINTAR by Ns. AMIRUL telah disinkronisasi dengan PPNI untuk memastikan kepatuhan hukum dan medis.
            </p>
            <div className="pt-4 border-t border-white/20">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-semibold">Akurasi Data</span>
                <span className="text-sm">99.8%</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                <div className="h-full bg-white rounded-full w-[99.8%] transition-all duration-1000"></div>
              </div>
            </div>
            <Button variant="secondary" className="w-full text-accent font-bold rounded-full">Cek Integritas Data</Button>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
