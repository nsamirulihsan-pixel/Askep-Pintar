"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Eye, Hammer, GraduationCap, Users, Printer, PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const OTEK_TEMPLATES = {
  "Manajemen Jalan Napas": [
    { id: "o1", type: "O", task: "Monitor pola napas (frekuensi, kedalaman, usaha napas)" },
    { id: "o2", type: "O", task: "Monitor bunyi napas tambahan (mis: gurgling, mengi, wheezing, ronkhi kering)" },
    { id: "t1", type: "T", task: "Pertahankan kepatenan jalan napas dengan head-tilt dan chin-lift" },
    { id: "t2", type: "T", task: "Posisikan semi-fowler atau fowler" },
    { id: "e1", type: "E", task: "Ajarkan teknik batuk efektif" },
    { id: "e2", type: "E", task: "Anjurkan asupan cairan 2000 ml/hari, jika tidak kontraindikasi" },
    { id: "k1", type: "K", task: "Kolaborasi pemberian bronkodilator, ekspektoran, mukolitik, jika perlu" },
  ],
  "Manajemen Hipovolemia": [
    { id: "o3", type: "O", task: "Periksa tanda dan gejala hipovolemia (mis: nadi teraba lemah, tekanan darah menurun)" },
    { id: "o4", type: "O", task: "Monitor intake dan output cairan" },
    { id: "t3", type: "T", task: "Hitung kebutuhan cairan" },
    { id: "t4", type: "T", task: "Berikan asupan cairan oral" },
    { id: "e3", type: "E", task: "Anjurkan memperbanyak asupan cairan oral" },
    { id: "k2", type: "K", task: "Kolaborasi pemberian cairan IV isotonis (mis: NaCl, RL)" },
  ]
};

export default function OtekPage() {
  const [selectedTemplate, setSelectedTemplate] = useState<keyof typeof OTEK_TEMPLATES>("Manajemen Jalan Napas");
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  const tasks = OTEK_TEMPLATES[selectedTemplate];
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => checkedItems[t.id]).length;
  const progress = (completedTasks / totalTasks) * 100;

  const toggleCheck = (id: string) => {
    setCheckedItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const getIcon = (type: string) => {
    switch(type) {
      case 'O': return <Eye className="h-4 w-4 text-blue-500" />;
      case 'T': return <Hammer className="h-4 w-4 text-purple-500" />;
      case 'E': return <GraduationCap className="h-4 w-4 text-green-500" />;
      case 'K': return <Users className="h-4 w-4 text-orange-500" />;
      default: return null;
    }
  };

  const getTypeName = (type: string) => {
    switch(type) {
      case 'O': return 'Observasi';
      case 'T': return 'Terapeutik';
      case 'E': return 'Edukasi';
      case 'K': return 'Kolaborasi';
      default: return '';
    }
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="flex justify-between items-end no-print">
        <div className="space-y-2">
          <h1 className="text-3xl font-headline font-bold text-primary">Protokol OTEK</h1>
          <p className="text-muted-foreground">Strukturisasi intervensi untuk efisiensi alur kerja bangsal.</p>
        </div>
        <Button variant="outline" onClick={() => window.print()}>
          <Printer className="h-4 w-4 mr-2" />
          Print Protokol
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 space-y-6 no-print">
          <Card className="border-none shadow-sm">
            <CardHeader>
              <CardTitle>Pilih Template Intervensi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {Object.keys(OTEK_TEMPLATES).map((name) => (
                <Button
                  key={name}
                  variant={selectedTemplate === name ? "default" : "ghost"}
                  className="w-full justify-start rounded-xl"
                  onClick={() => setSelectedTemplate(name as keyof typeof OTEK_TEMPLATES)}
                >
                  {name}
                </Button>
              ))}
              <Button variant="outline" className="w-full justify-start rounded-xl border-dashed">
                <PlusCircle className="h-4 w-4 mr-2" />
                Tambah Template Baru
              </Button>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm bg-primary text-white">
            <CardHeader>
              <CardTitle className="text-lg">Progres Intervensi</CardTitle>
              <CardDescription className="text-primary-foreground/70">Tindakan yang telah diverifikasi</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between text-sm">
                <span>{completedTasks} dari {totalTasks} selesai</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2 bg-white/20" />
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-8">
          <Card className="border-none shadow-sm overflow-hidden min-h-[600px]">
            <CardHeader className="bg-white border-b sticky top-0 z-10">
              <div className="flex justify-between items-center">
                <CardTitle>{selectedTemplate}</CardTitle>
                <div className="flex gap-2 no-print">
                  <span className="flex items-center gap-1 text-[10px] uppercase font-bold text-blue-500 bg-blue-50 px-2 py-0.5 rounded">O</span>
                  <span className="flex items-center gap-1 text-[10px] uppercase font-bold text-purple-500 bg-purple-50 px-2 py-0.5 rounded">T</span>
                  <span className="flex items-center gap-1 text-[10px] uppercase font-bold text-green-500 bg-green-50 px-2 py-0.5 rounded">E</span>
                  <span className="flex items-center gap-1 text-[10px] uppercase font-bold text-orange-500 bg-orange-50 px-2 py-0.5 rounded">K</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y">
                {['O', 'T', 'E', 'K'].map((type) => {
                  const items = tasks.filter(t => t.type === type);
                  if (items.length === 0) return null;
                  
                  return (
                    <div key={type} className="p-6">
                      <div className="flex items-center gap-2 mb-4">
                        {getIcon(type)}
                        <h3 className="font-bold text-sm tracking-widest uppercase text-muted-foreground">
                          {getTypeName(type)}
                        </h3>
                      </div>
                      <div className="space-y-4">
                        {items.map((item) => (
                          <div 
                            key={item.id} 
                            className={cn(
                              "flex items-start gap-4 p-4 rounded-xl transition-all group",
                              checkedItems[item.id] ? "bg-muted/50 opacity-60" : "hover:bg-muted/30"
                            )}
                          >
                            <Checkbox 
                              id={item.id} 
                              checked={checkedItems[item.id]} 
                              onCheckedChange={() => toggleCheck(item.id)}
                              className="mt-1 no-print"
                            />
                            <label 
                              htmlFor={item.id} 
                              className={cn(
                                "text-sm leading-relaxed font-body cursor-pointer flex-1",
                                checkedItems[item.id] && "line-through"
                              )}
                            >
                              {item.task}
                            </label>
                            {checkedItems[item.id] && (
                              <Badge className="bg-accent no-print">Selesai</Badge>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
