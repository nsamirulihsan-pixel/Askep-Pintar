import type { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'ASKEP PINTAR by Ns. AMIRUL',
    short_name: 'ASKEP PINTAR',
    description: 'Solusi Asuhan Keperawatan Digital berbasis SDKI, SLKI, SIKI dan ICD-10.',
    start_url: '/',
    display: 'standalone',
    orientation: 'portrait',
    background_color: '#F2F7F7',
    theme_color: '#247B82',
    icons: [
      {
        src: 'https://picsum.photos/seed/appicon/192/192',
        sizes: '192x192',
        type: 'image/png',
        purpose: 'maskable',
      },
      {
        src: 'https://picsum.photos/seed/appicon/512/512',
        sizes: '512x512',
        type: 'image/png',
        purpose: 'any',
      },
    ],
    categories: ['education', 'medical', 'productivity'],
    screenshots: [
      {
        src: 'https://picsum.photos/seed/screenshot1/1080/1920',
        sizes: '1080x1920',
        type: 'image/png',
        label: 'Tampilan Utama ASKEP PINTAR'
      },
      {
        src: 'https://picsum.photos/seed/screenshot2/1080/1920',
        sizes: '1080x1920',
        type: 'image/png',
        label: 'Analisis AI 3S & SOAP'
      }
    ]
  }
}
