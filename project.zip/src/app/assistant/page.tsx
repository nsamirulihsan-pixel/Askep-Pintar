"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { aiAssistedCarePlanGeneration, AiAssistedCarePlanGenerationOutput } from "@/ai/flows/ai-assisted-care-plan-generation";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Sparkles, Loader2, Printer, CheckCircle2, AlertCircle, Eye, Hammer, GraduationCap, Users, ClipboardList, BookOpen, Share2, ListChecks } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

function AssistantContent() {
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AiAssistedCarePlanGenerationOutput | null>(null);
  const { toast } = useToast();
  const searchParams = useSearchParams();

  useEffect(() => {
    const prefill = searchParams.get("prefill");
    if (prefill) {
      setDescription(decodeURIComponent(prefill));
    }
  }, [searchParams]);

  const handleGenerate = async () => {
    if (!description.trim()) {
      toast({
        title: "Input Kosong",
        description: "Harap masukkan deskripsi status pasien.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const output = await aiAssistedCarePlanGeneration({ patientDescription: description });
      setResult(output);
      toast({
        title: "Berhasil",
        description: "Rencana asuhan dan SOAP profesional telah dibuat.",
      });
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Gagal membuat rencana asuhan. Coba lagi nanti.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleShareResult = async () => {
    if (!result) return;
    
    const shareText = `Laporan Askep: ${result.soap.a}\nS: ${result.soap.s}\nO: ${result.soap.o}\n\nDibuat via ASKEP PINTAR by Ns. AMIRUL`;
    
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'Hasil Askep & SOAP',
          text: shareText,
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(shareText);
        toast({
          title: "Teks Disalin",
          description: "Ringkasan SOAP telah disalin ke papan klip.",
        });
      }
    } catch (err) {
      console.error('Error sharing:', err);
    }
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="space-y-2 no-print">
        <h1 className="text-3xl font-headline font-bold text-primary flex items-center gap-2">
          <Sparkles className="h-8 w-8 text-amber-500" />
          Asisten Perawatan Cerdas (AI)
        </h1>
        <p className="text-muted-foreground">Analisis narasi klinis untuk rekomendasi SDKI, SLKI, SIKI, dan SOAP sesuai standar PPNI terbaru.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Input Card */}
        <Card className="lg:col-span-4 border-none shadow-sm no-print">
          <CardHeader>
            <CardTitle>Data Pasien</CardTitle>
            <CardDescription>Masukkan keluhan, riwayat, dan hasil observasi klinis.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="Contoh: Pasien masuk dengan keluhan sesak napas sejak tadi pagi, RR 28x/mnt, TD 140/90, auskultasi ronkhi..."
              className="min-h-[250px] font-body text-base"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <Button 
              className="w-full rounded-full h-12 text-lg font-bold" 
              onClick={handleGenerate}
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Menganalisis...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  Buat Rencana & SOAP
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Result Area */}
        <div className="lg:col-span-8 space-y-6">
          {!result && !loading && (
            <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-center p-8 bg-muted/20 rounded-3xl border-2 border-dashed border-muted no-print">
              <BookOpen className="h-12 w-12 text-muted mb-4" />
              <p className="text-muted-foreground font-body text-lg">
                Rencana asuhan dan SOAP akan tampil di sini setelah Anda memasukkan data pasien.
              </p>
            </div>
          )}

          {loading && (
            <div className="h-full min-h-[400px] flex flex-col items-center justify-center space-y-4 no-print">
              <div className="relative">
                <div className="h-20 w-20 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-8 w-8 text-primary animate-pulse" />
              </div>
              <p className="text-primary font-bold animate-pulse">AI sedang menyusun dokumentasi klinis 3S & SOAP...</p>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-fade-in-up">
              <div className="flex justify-between items-center no-print">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-accent" />
                  Hasil Rekomendasi Klinis
                </h2>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleShareResult} className="rounded-full">
                    <Share2 className="h-4 w-4 mr-2" />
                    Bagikan
                  </Button>
                  <Button variant="outline" size="sm" onClick={handlePrint} className="rounded-full">
                    <Printer className="h-4 w-4 mr-2" />
                    Cetak
                  </Button>
                </div>
              </div>

              {/* Print Header */}
              <div className="hidden print:block mb-8 border-b-2 border-black pb-4 text-center">
                <h1 className="text-2xl font-bold uppercase">LAPORAN ASUHAN KEPERAWATAN & CPPT</h1>
                <p className="text-sm">ASKEP PINTAR by Ns. AMIRUL</p>
                <div className="text-left mt-8 space-y-1">
                  <p><strong>Narasi Klinis:</strong> {description}</p>
                  <p><strong>Tanggal/Jam:</strong> {new Date().toLocaleString('id-ID', { dateStyle: 'long', timeStyle: 'short' })}</p>
                </div>
              </div>

              <Tabs defaultValue="careplan" className="w-full no-print">
                <TabsList className="grid w-full grid-cols-2 rounded-full h-12">
                  <TabsTrigger value="careplan" className="rounded-full">Rencana Asuhan (3S)</TabsTrigger>
                  <TabsTrigger value="cppt" className="rounded-full">Format SOAP CPPT</TabsTrigger>
                </TabsList>
                
                <TabsContent value="careplan" className="space-y-6 mt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* SDKI Card */}
                    <Card className="border-none shadow-sm overflow-hidden h-fit">
                      <CardHeader className="bg-primary/5 border-b border-primary/10">
                        <CardTitle className="text-primary text-lg flex items-center justify-between">
                          SDKI (Diagnosis)
                          <Badge variant="outline">Label Standar</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-4 space-y-3">
                        {result.sdki.map((item, idx) => (
                          <div key={idx} className="flex gap-3 items-start">
                            <span className="bg-primary text-white text-[10px] font-bold h-5 w-5 rounded-full flex items-center justify-center shrink-0 mt-1">{item.priority}</span>
                            <p className="font-body text-sm leading-relaxed">{item.description}</p>
                          </div>
                        ))}
                      </CardContent>
                    </Card>

                    {/* SLKI Card */}
                    <Card className="border-none shadow-sm overflow-hidden h-fit">
                      <CardHeader className="bg-accent/5 border-b border-accent/10">
                        <CardTitle className="text-accent text-lg flex items-center justify-between">
                          SLKI (Luaran)
                          <Badge variant="outline" className="border-accent text-accent">Kriteria Hasil</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-4 space-y-3">
                        {result.slki.map((item, idx) => (
                          <div key={idx} className="flex gap-3 items-start">
                            <span className="bg-accent text-white text-[10px] font-bold h-5 w-5 rounded-full flex items-center justify-center shrink-0 mt-1">{item.priority}</span>
                            <p className="font-body text-sm leading-relaxed">{item.description}</p>
                          </div>
                        ))}
                      </CardContent>
                    </Card>
                  </div>

                  {/* SIKI Card */}
                  <Card className="border-none shadow-sm overflow-hidden">
                    <CardHeader className="bg-amber-50 border-b border-amber-100">
                      <CardTitle className="text-amber-700 flex items-center justify-between text-lg">
                        SIKI (Intervensi OTEK)
                        <Badge variant="outline" className="border-amber-500 text-amber-700">Rincian Tindakan</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="divide-y divide-amber-100">
                        {result.siki.map((item, idx) => (
                          <div key={idx} className="p-6 space-y-4">
                            <div className="flex items-center gap-2">
                              <span className="bg-amber-500 text-white text-xs font-bold h-6 w-6 rounded-full flex items-center justify-center shrink-0">{item.priority}</span>
                              <h3 className="font-bold text-amber-900 uppercase tracking-tight">{item.title}</h3>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              <div className="space-y-2">
                                <div className="flex items-center gap-2 text-blue-600 font-bold text-xs uppercase"><Eye className="h-3 w-3" /> Observasi</div>
                                <ul className="space-y-1">{item.details.observasi.map((act, i) => <li key={i} className="text-xs text-muted-foreground border-l-2 border-blue-200 pl-2">{act}</li>)}</ul>
                              </div>
                              <div className="space-y-2">
                                <div className="flex items-center gap-2 text-purple-600 font-bold text-xs uppercase"><Hammer className="h-3 w-3" /> Terapeutik</div>
                                <ul className="space-y-1">{item.details.terapeutik.map((act, i) => <li key={i} className="text-xs text-muted-foreground border-l-2 border-purple-200 pl-2">{act}</li>)}</ul>
                              </div>
                              <div className="space-y-2">
                                <div className="flex items-center gap-2 text-green-600 font-bold text-xs uppercase"><GraduationCap className="h-3 w-3" /> Edukasi</div>
                                <ul className="space-y-1">{item.details.edukasi.map((act, i) => <li key={i} className="text-xs text-muted-foreground border-l-2 border-green-200 pl-2">{act}</li>)}</ul>
                              </div>
                              <div className="space-y-2">
                                <div className="flex items-center gap-2 text-orange-600 font-bold text-xs uppercase"><Users className="h-3 w-3" /> Kolaborasi</div>
                                <ul className="space-y-1">{item.details.kolaborasi.map((act, i) => <li key={i} className="text-xs text-muted-foreground border-l-2 border-orange-200 pl-2">{act}</li>)}</ul>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="cppt" className="mt-6 space-y-6">
                  <Card className="border-none shadow-sm overflow-hidden border-l-4 border-l-accent">
                    <CardHeader className="bg-accent/5">
                      <div className="flex justify-between items-center">
                        <div>
                          <CardTitle className="text-accent flex items-center gap-2">
                            <ClipboardList className="h-5 w-5" />
                            Catatan Perkembangan (CPPT)
                          </CardTitle>
                          <CardDescription>Format SOAP sesuai standar rekam medis digital.</CardDescription>
                        </div>
                        <Badge className="bg-accent">Validasi AI 3S</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6 space-y-6">
                      <div className="grid grid-cols-1 gap-6">
                        <div className="flex gap-4">
                          <div className="bg-muted h-10 w-10 rounded-full flex items-center justify-center font-bold text-primary shrink-0 border border-primary/20">S</div>
                          <div className="space-y-1 flex-1">
                            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Subjective</p>
                            <p className="text-sm font-body bg-muted/30 p-3 rounded-lg border-l-2 border-primary">{result.soap.s}</p>
                          </div>
                        </div>
                        <div className="flex gap-4">
                          <div className="bg-muted h-10 w-10 rounded-full flex items-center justify-center font-bold text-primary shrink-0 border border-primary/20">O</div>
                          <div className="space-y-1 flex-1">
                            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Objective</p>
                            <p className="text-sm font-body bg-muted/30 p-3 rounded-lg border-l-2 border-primary">{result.soap.o}</p>
                          </div>
                        </div>
                        <div className="flex gap-4">
                          <div className="bg-muted h-10 w-10 rounded-full flex items-center justify-center font-bold text-primary shrink-0 border border-primary/20">A</div>
                          <div className="space-y-1 flex-1">
                            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Assessment</p>
                            <p className="text-sm font-body bg-muted/30 p-3 rounded-lg border-l-2 border-primary font-bold">{result.soap.a}</p>
                          </div>
                        </div>
                        <div className="flex gap-4">
                          <div className="bg-muted h-10 w-10 rounded-full flex items-center justify-center font-bold text-primary shrink-0 border border-primary/20">P</div>
                          <div className="space-y-1 flex-1">
                            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Plan</p>
                            <p className="text-sm font-body bg-muted/30 p-3 rounded-lg border-l-2 border-primary">{result.soap.p}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Implementasi / Instruksi PPA UI View */}
                  <Card className="border-none shadow-sm overflow-hidden border-l-4 border-l-amber-500">
                    <CardHeader className="bg-amber-50">
                      <CardTitle className="text-amber-700 flex items-center gap-2 text-lg">
                        <ListChecks className="h-5 w-5" />
                        Instruksi PPA (Implementasi Keperawatan)
                      </CardTitle>
                      <CardDescription>Tindakan operasional yang direkomendasikan untuk kolom instruksi CPPT.</CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      <ul className="space-y-2">
                        {result.ppaInstructions.map((inst, idx) => (
                          <li key={idx} className="flex gap-3 text-sm font-body p-2 rounded hover:bg-muted/50 transition-colors">
                            <span className="text-amber-600 font-bold">•</span>
                            {inst}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              {/* Print Only View for CPPT Table */}
              <div className="hidden print:block space-y-8">
                <h3 className="text-lg font-bold border-b-2 border-black pb-2">Catatan Perkembangan Pasien Terintegrasi (CPPT)</h3>
                <table className="w-full border-collapse border-2 border-black text-sm">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-black p-2 w-[12%]">Tgl/Jam</th>
                      <th className="border border-black p-2 w-[12%]">Profesi</th>
                      <th className="border border-black p-2 w-[38%]">Hasil Asesmen (SOAP)</th>
                      <th className="border border-black p-2 w-[28%]">Instruksi PPA (Implementasi)</th>
                      <th className="border border-black p-2 w-[10%]">Ttd</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-black p-2 align-top text-xs">
                        {new Date().toLocaleDateString('id-ID')}<br/>
                        {new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="border border-black p-2 align-top text-center font-bold">Perawat</td>
                      <td className="border border-black p-2 space-y-3 align-top">
                        <p><strong>S:</strong> {result.soap.s}</p>
                        <p><strong>O:</strong> {result.soap.o}</p>
                        <p><strong>A:</strong> {result.soap.a}</p>
                        <p><strong>P:</strong> {result.soap.p}</p>
                      </td>
                      <td className="border border-black p-2 align-top">
                        <ul className="list-disc pl-4 space-y-1 text-xs">
                          {result.ppaInstructions.map((inst, idx) => (
                            <li key={idx}>{inst}</li>
                          ))}
                        </ul>
                      </td>
                      <td className="border border-black p-2 align-bottom text-center text-[8px] uppercase h-40">
                        <div className="border-t border-dotted border-black pt-1">
                          Ns. Amirul
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 flex gap-3 no-print">
                <AlertCircle className="h-5 w-5 text-blue-500 shrink-0" />
                <p className="text-sm text-blue-700 font-body">
                  Dokumentasi SOAP dan Implementasi ini dihasilkan secara otomatis berdasarkan standar SDKI, SLKI, dan SIKI. Verifikasi kembali data sebelum melakukan finalisasi rekam medis.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function AssistantPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-screen"><Loader2 className="animate-spin" /></div>}>
      <AssistantContent />
    </Suspense>
  );
}