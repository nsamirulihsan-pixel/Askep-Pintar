
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Stethoscope, Search, Sparkles, BookOpen } from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/", icon: Stethoscope },
  { name: "ICD Navigator", href: "/icd-navigator", icon: Search },
  { name: "AI Assistant", href: "/assistant", icon: Sparkles },
  { name: "Protokol OTEK", href: "/otek", icon: BookOpen },
];

export function Navbar() {
  const pathname = usePathname();

  return (
    <nav className="bg-white border-b border-border sticky top-0 z-50 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center gap-2">
              <div className="bg-primary p-2 rounded-lg">
                <Stethoscope className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="flex flex-col leading-tight">
                <span className="font-headline font-bold text-lg text-primary tracking-tight">
                  ASKEP PINTAR
                </span>
                <span className="text-[10px] font-bold text-accent uppercase tracking-wider">
                  by Ns. AMIRUL
                </span>
              </div>
            </Link>
          </div>
          <div className="hidden sm:flex sm:space-x-8 items-center">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "inline-flex items-center px-1 pt-1 text-sm font-medium transition-colors border-b-2 h-16 gap-2",
                    isActive
                      ? "border-primary text-primary"
                      : "border-transparent text-muted-foreground hover:text-primary hover:border-gray-300"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {item.name}
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}
